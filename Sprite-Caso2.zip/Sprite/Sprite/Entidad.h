#pragma once
enum Direccion { Arriba, Abajo, Izquierda, Derecha };

class Entidad
{
protected:
	int x, y;
	int dx, dy;
	int ancho, alto;
	int fila, columna;

public:
	Entidad();
	~Entidad();

	int GetX();
	int GetY();
	int GetDX();
	int GetDY();
	int GetAncho();
	int GetAlto();
	int GetFila();
	int GetColumna();

	void SetX(int n);
	void SetY(int n);
	void SetDX(int n);
	void SetDY(int n);
	void SetAncho(int n);
	void SetAlto(int n);
	void SetFila(int n);
	void SetColumna(int n);

	virtual void Mostrar();
	virtual void Mover(Direccion direccion);
	

};

