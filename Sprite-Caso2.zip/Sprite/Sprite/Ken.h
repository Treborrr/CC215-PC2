#pragma once
#include "Entidad.h"
using namespace System::Drawing;


class Ken :  public Entidad
{
public:
	Ken();
	~Ken();
	
	void Mostrar(Graphics^ g, Bitmap^ img);
	void Mover(Direccion direccion);
};

