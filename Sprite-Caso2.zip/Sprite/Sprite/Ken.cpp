#include "Ken.h"
using namespace System;
Ken::Ken()
{
	Random j;
	x = y = j.Next(10, 40);
	dx = dy = 4; 
	fila, columna = 0;

}
Ken::~Ken()
{
}
void Ken::Mostrar(Graphics^ g, Bitmap^ img)
{
	alto = img->Height;
	ancho = img->Width/6 ;

	
    Rectangle molde = Rectangle(columna * ancho,0,ancho, alto);
	g->DrawImage(img,x,y,molde,GraphicsUnit::Pixel);

	columna++;
	if (columna == 3)
		columna = 0;
}
void Ken::Mover(Direccion direccion)
{
	switch (direccion)
	{
	case Direccion::Arriba:
		y -= dy;
		columna = 3;
		break;
	case Direccion::Abajo:
		y += dy;
		columna = 0;
		break;
	case Direccion::Izquierda:
		x -= dx;
		columna = 1;
		break;
	case Direccion::Derecha:
		x += dx;
		columna = 2;
		break;
	default:
		break;
	}
}